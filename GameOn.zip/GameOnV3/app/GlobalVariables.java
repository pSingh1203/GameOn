import android.app.Application;

public class GlobalVariables extends Application {
    public String ENum="HI";

}
