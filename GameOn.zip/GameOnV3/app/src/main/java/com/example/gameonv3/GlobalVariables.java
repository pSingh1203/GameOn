package com.example.gameonv3;

import android.app.Application;

public class GlobalVariables extends Application {
    public static String ENum;
    public static String booking1;
    public static String booking2;
    public static String[][] tempData=new String[8][4];
    public static String list;
    public static int flaty=0;
}
